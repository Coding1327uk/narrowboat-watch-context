---
id: api.overview
title: API Overview
version: 0.2.0
owners: [simon]
last_updated: 2025-08-13
related: [api.mobile, api.admin]
status: draft
---

Two primary contracts: Mobile (user-facing) and Admin (management). Auth via Firebase Auth.
