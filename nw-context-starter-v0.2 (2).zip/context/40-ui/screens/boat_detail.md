---
id: ui.screen.boat_detail
title: Screen — Boat Detail
version: 0.2.0
owners: [simon]
last_updated: 2025-08-13
status: draft
---

**Sections**
- Boat info
- Sensors (cards)
- Last telemetry timeline
- Actions: Assign owner, add sensor, configure alerts
