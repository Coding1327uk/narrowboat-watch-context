---
id: ui.screen.alerts
title: Screen — Alerts
version: 0.2.0
owners: [simon]
last_updated: 2025-08-13
status: draft
---

List and manage alert rules. Create/edit forms with condition builder (lhs, operator, rhs), scope picker (groups/boats), channels (email/sms/push).
