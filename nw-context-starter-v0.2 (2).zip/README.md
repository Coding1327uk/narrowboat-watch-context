# Narrowboat Watch — Context Repo (v0.2 seed)

This repository is the **source of truth** for system design and behaviour.
It is separate from application code and should be tagged when a build consumes it.

**This seed is pre-filled** with initial drafts for DB, Roles, UI screens, Alerts,
Telemetry formats, API skeletons, Firestore rules & indexes, ADRs, and a manifest.
