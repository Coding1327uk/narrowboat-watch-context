# Changelog
All notable changes to this repository will be documented here.

## [0.2.0] - 2025-08-13
### Added
- Filled DB collections, Alerts, Telemetry, Roles, UI screens, API skeletons.
- Firestore security rules and indexes (draft).
- ADRs accepted status.
- Manifest updated.
