---
id: ui.screen.dashboard
title: Screen — Dashboard
version: 0.2.0
owners: [simon]
last_updated: 2025-08-13
status: draft
---

**Widgets**: Active alerts, boats list by group, quick filters.  
**Filters**: Group, status (OK/Warning/Critical), text search.  
**Actions**: View boat, acknowledge alert (if permission).
